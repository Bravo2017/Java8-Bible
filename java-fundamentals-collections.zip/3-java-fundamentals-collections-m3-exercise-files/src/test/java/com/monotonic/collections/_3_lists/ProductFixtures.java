package com.monotonic.collections._3_lists;

import com.monotonic.collections.Product;

public class ProductFixtures
{
    public static Product door = new Product("Wooden Door", 35);
    public static Product floorPanel = new Product("Floor Panel", 25);
    public static Product window = new Product("Glass Window", 10);
}
