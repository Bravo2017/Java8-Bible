package com.monotonic.collections;

public class ProductFixtures
{
    public static Product door = new Product(1, "Wooden Door", 35);
    public static Product floorPanel = new Product(2, "Floor Panel", 25);
    public static Product window = new Product(3, "Glass Window", 10);
}
