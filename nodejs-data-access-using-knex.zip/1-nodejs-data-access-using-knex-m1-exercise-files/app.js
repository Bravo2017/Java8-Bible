var cfg    = require("./knex-cfg").sqlite;
var screen = require("./screen");
var knex   = require("knex")(cfg);

screen.clear();

knex.select("title", "rating").from("book").asCallback(function(err, rows)
{
	if(err) { console.error(err); }
	else
	{
		screen.write(rows, "pretty");	
	}
	knex.destroy();
	console.log("Done.");
});



