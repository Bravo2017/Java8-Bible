Instructions:

Assuming you have installed Node.js, you can run this demo by entering the project folder and typing:

> npm install

You can then run the program by typing:

> node app.js



