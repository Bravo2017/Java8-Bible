var cfg    = require("./knex-cfg").sqlite;
var screen = require("./screen");
var knex   = require("knex")(cfg);

screen.clear();

var charles = { firstname: "Charles", lastname: "Dickens" };
var bill    = { firstname: "William", lastname: "Shakespeare" };
var ed      = { firstname: "Edgar",   lastname: "Poe" };
var doc     = { firstname: "Dr.",     lastname: "Seuss" };

knex("author").where("id", ">", 4).del().then(function (id)
{
    console.log(id);
    return knex("author");  //knex.select("*").from("author");
})
.then(function (rows)
{
    screen.write(rows, "pretty");
})
.finally(function ()
{
    knex.destroy();
});