var cfg    = require("./knex-cfg").sqlite;
var screen = require("./screen");
var knex   = require("knex")(cfg);

screen.clear();

var query = knex("book").column("title", "rating");
run(query, "pretty");


function run(knexQuery, mode)
{
    return knexQuery.then(function (rows)
    {
        screen.write(rows, mode);
    })
	.catch(function (err)
	{
	    screen.write("Oops");
	    screen.write(err);
	})
	.finally(function ()
	{
	    knex.destroy();
	});
}