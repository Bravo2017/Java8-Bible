Instructions:

Assuming you have installed Node.js, you can install the dependencies for this demo by entering the moviedb folder and running:

> npm install

and then installing knex globally:

> npm install knex -g

You can then run the migration or seed files by using the knex CLI.



