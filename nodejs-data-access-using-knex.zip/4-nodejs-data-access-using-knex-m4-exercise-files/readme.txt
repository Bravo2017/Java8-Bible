Instructions:

Assuming you have installed Node.js, you can install the dependencies for this demo by entering the moviedb folder and running:

> npm install

You can then run the application by typing

> node app.js




